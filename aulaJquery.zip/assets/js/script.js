		$(document).ready( function() {
			
			$("#header").load("header.html");
			$("#nav").load("nav.html");
			$("#section").load("section1.html");
			$("#footer").load("footer.html");
			

		} );
